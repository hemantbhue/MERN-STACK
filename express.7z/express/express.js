const express  = require("express");
const app = express();

app.get('/',function(request,response){
    response.send("HELLO EXPRESS WORLD");
})

app.get('/aboutme',function(request,response){
    response.send("ABOUT ME PAGE");
})

app.listen(3000, function(){
    console.log("server started on Port 3000");
});