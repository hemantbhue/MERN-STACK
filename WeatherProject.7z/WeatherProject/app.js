const express = require('express');
const bodyParse = require('body-parser');
const http = require('https');

const app = express();
app.use(bodyParse.urlencoded({extended : true}));


app.get("/", function(req,res){
    res.sendFile(__dirname+"/index.html");
})
app.post("/", function(req,res){
    const city = req.body.city;
    
    http.get('https://api.openweathermap.org/data/2.5/weather?q='+ city +'&appid=f2afb08e854c63363d194787dd04af4b', function(response){
    console.log(response.statusCode);
    response.on("data", function(data){
        const weatherData  = JSON.parse(data);
        const desc = weatherData.weather[0].description;
        const temperature = weatherData.main.temp;
        res.send("<h1>The weather in "+city+" is " + desc + " and temperature is " + temperature +"</h1>");
    })
});
})



app.listen(3000, function(){
    console.log("server is running on port 3000")
})