const mongoose = require('mongoose');

mongoose.connect("mongodb://localhost:27017/fruitsDB", {useNewUrlParser: true});

const fruitSchema = new mongoose.Schema({
    name: String,
    rating: Number,
    review : String
});

//In Mongoose way of workign we specify the first parameter inside the model function to be a string then mongoose converts it into a prural form as the collection name
const Fruit = mongoose.model("Fruit", fruitSchema);//Fruit MODEL

//creating a document from the model defined above
const fruit  = new Fruit({
    name: "Apple",
    rating: 7,
    review: "pretty solid as fruit"
});

fruit.save();//saves the fruit document in Fruits Collection in fruitsDB.
