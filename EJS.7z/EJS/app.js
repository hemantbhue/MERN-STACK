const express = require('express');
const bodyParser = require('body-parser');
const date = require(__dirname + '/date.js');

const app = express();

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static('public'));
const newItems = ['football','wash clothes','clean house'];
const work = [];

app.get("/",function(req,res){
    
    day = date.getDate();

    res.render("list", {kindofday: day, newListItem: newItems});
});

app.post("/",  function(req,res){
    var newItem = req.body.newItem;
    console.log(req.body);
    if (req.body.list === 'work'){
        work.push(newItem);
        res.redirect('/work');
    } else {
        newItems.push(newItem);
        res.redirect("/");
    }
});

app.get("/work", function(req,res){
    res.render("list", {kindofday: 'work', newListItem: work});
});

app.listen(3000,function(){
    console.log("server is running on PORT 3000");
});